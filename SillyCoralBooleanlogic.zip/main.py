import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.font_manager import FontProperties
df = pd.read_csv('A.csv',encoding='utf-8')
a = df[df['發電方式']=='燃油']
data = a.loc[:, ['年度','排放量(萬噸)']]
data = data.set_index('年度')
fig = data.plot(kind='line').get_figure()
plt.title('Fire')
fig.savefig('fire.png')